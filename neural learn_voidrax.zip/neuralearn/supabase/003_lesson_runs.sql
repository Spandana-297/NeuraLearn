-- Lesson run log (the Progress page's activity calendar, weekly totals,
-- accuracy and recent activity). One row per finished lesson.
-- Run once in the Supabase SQL editor after schema.sql. Safe to run again.

create table if not exists public.lesson_runs (
  id uuid primary key,                       -- made in the browser, so a run is never saved twice
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  algorithm text not null check (char_length(algorithm) <= 40),
  finished_at timestamptz not null,
  ms bigint not null default 0 check (ms >= 0 and ms < 86400000),
  checkpoints integer not null default 0 check (checkpoints between 0 and 50),
  correct integer not null default 0 check (correct >= 0 and correct <= checkpoints),
  input text check (char_length(input) <= 500)
);
create index if not exists lesson_runs_user_finished on public.lesson_runs (user_id, finished_at desc);

alter table public.lesson_runs enable row level security;
drop policy if exists "own lesson runs" on public.lesson_runs;
create policy "own lesson runs" on public.lesson_runs for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
