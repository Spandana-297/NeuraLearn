-- NeuraLearn accounts: run this once in the Supabase SQL editor
-- (Dashboard -> SQL Editor -> New query -> paste -> Run).
--
-- The browser talks to Supabase directly with the public anon key. Row level
-- security below is what keeps each student's data private: every table only
-- returns and accepts rows whose user_id is the signed-in student.

-- Name and timezone used for greetings and streak days.
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  name text not null default '' check (char_length(name) <= 40),
  timezone text not null default 'UTC' check (char_length(timezone) <= 64),
  updated_at timestamptz not null default now()
);

-- One row per algorithm, mirroring the browser's nl.progress record.
create table if not exists public.topic_progress (
  user_id uuid not null references auth.users (id) on delete cascade,
  algorithm text not null check (char_length(algorithm) <= 40),
  done boolean not null default false,
  "right" boolean not null default false,   -- every checkpoint answered right at least once
  runs integer not null default 0 check (runs >= 0),
  ms bigint not null default 0 check (ms >= 0), -- total time spent in the lesson
  input text check (char_length(input) <= 500),
  target text check (char_length(target) <= 20),
  at timestamptz,                               -- last started or finished
  updated_at timestamptz not null default now(),
  primary key (user_id, algorithm)
);

-- The student's own notes from the Notes tab ("tutor" or an algorithm id).
create table if not exists public.notes (
  user_id uuid not null references auth.users (id) on delete cascade,
  key text not null check (char_length(key) <= 60),
  text text not null default '' check (char_length(text) <= 20000),
  updated_at timestamptz not null default now(),
  primary key (user_id, key)
);

-- Days (in the student's timezone) on which at least one lesson was finished.
create table if not exists public.streak_days (
  user_id uuid not null references auth.users (id) on delete cascade,
  day date not null,
  primary key (user_id, day)
);

-- The bell's notifications, so they survive a refresh and follow the student.
create table if not exists public.notifications (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  kind text not null default '' check (char_length(kind) <= 20),
  text text not null check (char_length(text) <= 300),
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index if not exists notifications_user_created on public.notifications (user_id, created_at desc);

-- Row level security: each student sees and changes only their own rows.
alter table public.profiles enable row level security;
alter table public.topic_progress enable row level security;
alter table public.notes enable row level security;
alter table public.streak_days enable row level security;
alter table public.notifications enable row level security;

drop policy if exists "own profile" on public.profiles;
create policy "own profile" on public.profiles for all to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));

drop policy if exists "own progress" on public.topic_progress;
create policy "own progress" on public.topic_progress for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

drop policy if exists "own notes" on public.notes;
create policy "own notes" on public.notes for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

drop policy if exists "own streak days" on public.streak_days;
create policy "own streak days" on public.streak_days for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

drop policy if exists "own notifications" on public.notifications;
create policy "own notifications" on public.notifications for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Saved AI lectures (also in 002_saved_lectures.sql for projects set up earlier).
create table if not exists public.saved_lectures (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  title text not null check (char_length(title) between 1 and 200),
  kind text not null default 'chat' check (kind in ('chat', 'doc')),
  explanation text not null default '' check (char_length(explanation) <= 40000),
  -- [{ "title", "kind", "text", "html", "model", "pages" }], at most ~6 MB in all
  parts jsonb not null default '[]'::jsonb check (jsonb_typeof(parts) = 'array' and octet_length(parts::text) <= 6000000),
  part_count integer not null default 0 check (part_count >= 0),
  model text not null default '' check (char_length(model) <= 80),
  created_at timestamptz not null default now()
);
create index if not exists saved_lectures_user_created on public.saved_lectures (user_id, created_at desc);

alter table public.saved_lectures enable row level security;
drop policy if exists "own saved lectures" on public.saved_lectures;
create policy "own saved lectures" on public.saved_lectures for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Lesson run log (also in 003_lesson_runs.sql for projects set up earlier).
create table if not exists public.lesson_runs (
  id uuid primary key,                       -- made in the browser, so a run is never saved twice
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  algorithm text not null check (char_length(algorithm) <= 40),
  finished_at timestamptz not null,
  ms bigint not null default 0 check (ms >= 0 and ms < 86400000),
  checkpoints integer not null default 0 check (checkpoints between 0 and 50),
  correct integer not null default 0 check (correct >= 0 and correct <= checkpoints),
  input text check (char_length(input) <= 500)
);
create index if not exists lesson_runs_user_finished on public.lesson_runs (user_id, finished_at desc);

alter table public.lesson_runs enable row level security;
drop policy if exists "own lesson runs" on public.lesson_runs;
create policy "own lesson runs" on public.lesson_runs for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
