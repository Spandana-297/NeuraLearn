-- Saved AI lectures (the "Saved lectures" shelf in My Library).
-- Run once in the Supabase SQL editor after schema.sql. Safe to run again.
--
-- One row per lecture: the question, the written answer, and every part's
-- drawn lesson (its HTML) so it replays exactly, with no AI calls.

create table if not exists public.saved_lectures (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  title text not null check (char_length(title) between 1 and 200),
  kind text not null default 'chat' check (kind in ('chat', 'doc')),
  explanation text not null default '' check (char_length(explanation) <= 40000),
  -- [{ "title", "kind", "text", "html", "model", "pages" }], at most ~6 MB in all
  parts jsonb not null default '[]'::jsonb check (jsonb_typeof(parts) = 'array' and octet_length(parts::text) <= 6000000),
  part_count integer not null default 0 check (part_count >= 0),
  model text not null default '' check (char_length(model) <= 80),
  created_at timestamptz not null default now()
);
create index if not exists saved_lectures_user_created on public.saved_lectures (user_id, created_at desc);

alter table public.saved_lectures enable row level security;
drop policy if exists "own saved lectures" on public.saved_lectures;
create policy "own saved lectures" on public.saved_lectures for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
