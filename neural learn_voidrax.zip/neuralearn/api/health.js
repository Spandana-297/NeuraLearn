// Vercel function for /api/health: the same handler the local server uses.
export { default } from '../lib/vercel.mjs';
