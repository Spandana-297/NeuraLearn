// Vercel function for /api/ask: the same handler the local server uses.
export { default } from '../lib/vercel.mjs';
