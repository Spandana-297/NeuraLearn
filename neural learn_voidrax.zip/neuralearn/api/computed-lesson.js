// Vercel function for /api/computed-lesson: the same handler the local server uses.
export { default } from '../lib/vercel.mjs';
