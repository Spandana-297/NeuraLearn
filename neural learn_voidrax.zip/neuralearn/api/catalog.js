// Vercel function for /api/catalog: the same handler the local server uses.
export { default } from '../lib/vercel.mjs';
