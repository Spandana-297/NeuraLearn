// Vercel function for /api/tts: the same handler the local server uses.
export { default } from '../lib/vercel.mjs';
