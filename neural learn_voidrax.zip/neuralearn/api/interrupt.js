// Vercel function for /api/interrupt: the same handler the local server uses.
export { default } from '../lib/vercel.mjs';
