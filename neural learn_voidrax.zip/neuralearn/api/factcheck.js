// Vercel function for /api/factcheck: the same handler the local server uses.
export { default } from '../lib/vercel.mjs';
