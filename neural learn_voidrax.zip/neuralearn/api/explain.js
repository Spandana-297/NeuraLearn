// Vercel function for /api/explain: the same handler the local server uses.
export { default } from '../lib/vercel.mjs';
