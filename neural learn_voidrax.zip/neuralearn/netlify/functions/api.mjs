// Every /api/* request on Netlify runs the same request handler as the local
// server (server.mjs), through the adapter in lib/netlify.mjs.
import handler from '../../lib/netlify.mjs';

export default handler;

export const config = { path: '/api/*' };
