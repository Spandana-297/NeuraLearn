import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';

// The Vercel functions must answer exactly like the local server.
test('Vercel function entry serves the API through the shared handler', async t => {
  const { default: health } = await import('../api/health.js');
  const { default: catalog } = await import('../api/catalog.js');
  const { default: lesson } = await import('../api/computed-lesson.js');
  const server = http.createServer((req, res) => (req.url.startsWith('/api/health') ? health : req.url.startsWith('/api/catalog') ? catalog : lesson)(req, res));
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  t.after(() => server.close());
  const base = `http://127.0.0.1:${server.address().port}`;
  assert.equal((await fetch(`${base}/api/health`).then(r => r.json())).ok, true);
  assert.ok((await fetch(`${base}/api/catalog`).then(r => r.json())).modules.length >= 6);
  const r = await fetch(`${base}/api/computed-lesson`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ algorithm: 'stack', input: 'push 1, pop' }) }).then(r => r.json());
  assert.deepEqual(r.lesson.visual.data, ['push 1', 'pop']);
});
