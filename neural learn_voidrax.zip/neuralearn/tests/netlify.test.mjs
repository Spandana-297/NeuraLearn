import test from 'node:test';
import assert from 'node:assert/strict';

// The Netlify function must answer exactly like the local server, stream the
// explanation, and stop before Netlify's 60 second cut-off. A short time limit
// is set here so the cut-off can be tested without waiting.
Object.assign(process.env, {
  LLM_PROVIDER: 'gemini', GEMINI_API_KEY: 'test-key', GEMINI_MODELS: 'gemini-a,gemini-b', NL_TIME_LIMIT_MS: '6000',
});
delete process.env.OPENAI_API_KEY; delete process.env.XAI_API_KEY; delete process.env.GROK_API_KEY;

const realFetch = globalThis.fetch;
let gemini = null; // (url, init) => Response, set by each test
let wikipedia = () => new Response(JSON.stringify({ query: { search: [] } })); // the Wikipedia API, set by tests
globalThis.fetch = (url, init) => String(url).includes('generativelanguage') ? gemini(String(url), init) : String(url).includes('wikipedia.org') ? wikipedia(String(url), init) : realFetch(url, init);
const sse = parts => new Response(new ReadableStream({
  async start(c) {
    for (const [k, t] of parts.entries()) {
      const usageMetadata = { promptTokenCount: 120, candidatesTokenCount: 4 * (k + 1), thoughtsTokenCount: 30 };
      c.enqueue(new TextEncoder().encode(`data: ${JSON.stringify({ candidates: [{ content: { parts: [{ text: t }] } }], usageMetadata })}\n\n`)); await new Promise(r => setTimeout(r, 5));
    }
    c.close();
  },
}), { headers: { 'content-type': 'text/event-stream' } });

const { default: api, config } = await import('../netlify/functions/api.mjs');
const call = (path, body, headers = {}) => api(new Request(`https://example.netlify.app${path}`, body === undefined
  ? { headers } : { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) }));

test('Netlify function serves every /api route through the shared handler', async () => {
  assert.equal(config.path, '/api/*');
  assert.equal((await (await call('/api/health')).json()).ok, true);
  assert.ok((await (await call('/api/catalog')).json()).modules.length >= 6);
  const r = await (await call('/api/computed-lesson', { algorithm: 'stack', input: 'push 1, pop' })).json();
  assert.deepEqual(r.lesson.visual.data, ['push 1', 'pop']);
  assert.equal((await call('/api/explain', { topic: '' })).status, 400);
});

test('Netlify streams the explanation and hands a busy model over to the next', async () => {
  const asked = [];
  gemini = url => { asked.push(url.match(/models\/([^:]+)/)[1]); return url.includes('gemini-a') ? new Response('{"error":{"message":"overloaded"}}', { status: 503 }) : sse(['Hello ', 'world']); };
  const res = await call('/api/explain', { topic: 'stacks', stream: true });
  assert.match(res.headers.get('content-type'), /ndjson/);
  const lines = (await res.text()).trim().split('\n').map(l => JSON.parse(l));
  assert.equal(lines.filter(l => l.t).map(l => l.t).join(''), 'Hello world');
  const { usage, ...done } = lines.at(-1);
  assert.deepEqual(done, { done: true, model: 'gemini-b', skipped: ['gemini-a'], why: ['gemini-a: HTTP 503 overloaded'] });
  // Token counts come from the last chunk's running totals.
  assert.deepEqual({ ...usage, ms: 0 }, { calls: 1, in: 120, out: 8, think: 30, ms: 0 });
  assert.deepEqual(asked, ['gemini-a', 'gemini-b']);
});

test('/api/config offers accounts only when a valid Supabase project is set', async () => {
  delete process.env.SUPABASE_URL; delete process.env.SUPABASE_ANON_KEY;
  assert.deepEqual(await (await call('/api/config')).json(), { accounts: null });
  Object.assign(process.env, { SUPABASE_URL: 'https://evil.example.com', SUPABASE_ANON_KEY: 'x'.repeat(40) });
  assert.deepEqual(await (await call('/api/config')).json(), { accounts: null }, 'only *.supabase.co URLs');
  Object.assign(process.env, { SUPABASE_URL: 'https://abcd1234.supabase.co/', SUPABASE_ANON_KEY: 'public-anon-key-'.repeat(3) });
  assert.deepEqual(await (await call('/api/config')).json(), { accounts: { url: 'https://abcd1234.supabase.co', anonKey: 'public-anon-key-'.repeat(3) } });
  delete process.env.SUPABASE_URL; delete process.env.SUPABASE_ANON_KEY;
});

test('/api/ocr reads a page image with Gemini and rejects anything else', async () => {
  let sent = null;
  gemini = (url, init) => { sent = JSON.parse(init.body); return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: 'Chapter 3: Queues' }] } }], usageMetadata: { promptTokenCount: 900, candidatesTokenCount: 5 } }), { headers: { 'content-type': 'application/json' } }); };
  const ok = await call('/api/ocr', { image: 'data:image/jpeg;base64,' + 'A'.repeat(400), page: 1 });
  assert.equal(ok.status, 200);
  assert.deepEqual(await ok.json(), { text: 'Chapter 3: Queues', model: 'gemini-a' });
  assert.equal(sent.contents[0].parts[0].inline_data.mime_type, 'image/jpeg');
  assert.equal((await call('/api/ocr', { image: 'not base64 <script>' })).status, 400);
  assert.equal((await call('/api/ocr', { image: 'A'.repeat(960_000) })).status, 400);
});

test('Verified answers are written with Google Search and carry their sources', async () => {
  process.env.GEMINI_SEARCH_GROUNDING = 'true';
  let sentTools = null;
  gemini = (url, init) => {
    sentTools = JSON.parse(init.body).tools;
    const chunk = o => `data: ${JSON.stringify(o)}\n\n`;
    const meta = { groundingChunks: [{ web: { uri: 'https://redirect/a', title: 'en.wikipedia.org' } }], groundingSupports: [{ segment: { text: 'TCP uses a three-way handshake.' }, groundingChunkIndices: [0] }], webSearchQueries: ['tcp handshake'] };
    return new Response(new ReadableStream({ start(c) { c.enqueue(new TextEncoder().encode(chunk({ candidates: [{ content: { parts: [{ text: 'TCP uses a three-way handshake.' }] } }] }) + chunk({ candidates: [{ content: { parts: [{ text: '' }] }, groundingMetadata: meta }] }))); c.close(); } }), { headers: { 'content-type': 'text/event-stream' } });
  };
  const res = await call('/api/explain', { topic: 'How does TCP start? (grounded test)', stream: true, ground: true });
  const lines = (await res.text()).trim().split('\n').map(l => JSON.parse(l)), done = lines.at(-1);
  assert.deepEqual(sentTools, [{ google_search: {} }]);
  assert.deepEqual(done.sources.sources.map(s => [s.n, s.domain, s.trust]), [[1, 'en.wikipedia.org', 'trusted']]);
  assert.equal(done.sources.claims[0].trust, 'trusted');
  // Without Verified mode no search tool is sent.
  await call('/api/explain', { topic: 'How does TCP start? (plain test)', stream: true });
  assert.equal(sentTools, undefined);
  delete process.env.GEMINI_SEARCH_GROUNDING;
});

test('by default, Verified answers are written from Wikipedia passages and cite them', async () => {
  let prompt = '';
  wikipedia = url => new Response(JSON.stringify(url.includes('list=search')
    ? { query: { search: [{ title: 'Transmission Control Protocol' }] } }
    : { query: { pages: [{ title: 'Transmission Control Protocol', fullurl: 'https://en.wikipedia.org/wiki/Transmission_Control_Protocol', extract: 'The Transmission Control Protocol (TCP) is one of the main protocols of the Internet protocol suite and it is reliable.\n== Connection establishment ==\nTo establish a connection, TCP uses a three-way handshake of SYN, SYN-ACK and ACK messages between the two hosts.' }] } }));
  gemini = (url, init) => { const b = JSON.parse(init.body); prompt = b.contents[0].parts[0].text + b.system_instruction.parts[0].text; return sse(['TCP opens a connection with a three-way handshake. [1] ', 'It is like a polite greeting.']); };
  const lines = (await (await call('/api/explain', { topic: 'How does the TCP handshake work? (cited test)', stream: true, ground: true })).text()).trim().split('\n').map(l => JSON.parse(l));
  assert.deepEqual(lines[0], { looked: ['Transmission Control Protocol'] }, 'says what it read first');
  assert.match(prompt, /\[1\] Wikipedia, "Transmission Control Protocol"[\s\S]*three-way handshake/);
  assert.match(prompt, /square brackets/);
  const done = lines.at(-1);
  assert.equal(done.sources.mode, 'retrieved');
  assert.equal(done.sources.sources[0].url, 'https://en.wikipedia.org/wiki/Transmission_Control_Protocol');
  assert.deepEqual(done.sources.claims.map(c => [c.text, c.sources]), [['TCP opens a connection with a three-way handshake.', [1]]]);
  assert.equal(done.sources.counts.sentences, 2);
  assert.equal(done.sources.sources[0].used, true);
});

test('when the search quota is used up, the answer is still written, without sources', async () => {
  process.env.GEMINI_SEARCH_GROUNDING = 'true';
  const calls = [];
  gemini = (url, init) => {
    const grounded = !!JSON.parse(init.body).tools; calls.push(grounded);
    return grounded ? new Response('{"error":{"message":"You exceeded your current quota"}}', { status: 429 }) : sse(['A deque ', 'has two ends.']);
  };
  const lines = (await (await call('/api/explain', { topic: 'What is a deque? (search quota test)', stream: true, ground: true })).text()).trim().split('\n').map(l => JSON.parse(l));
  const done = lines.at(-1);
  assert.equal(lines.filter(l => l.t).map(l => l.t).join(''), 'A deque has two ends.');
  assert.equal(done.model, 'gemini-a', 'same model, asked again without searching');
  assert.deepEqual(calls, [true, false]);
  assert.equal(done.sources.none, true); assert.equal(done.sources.reason, 'quota');
  delete process.env.GEMINI_SEARCH_GROUNDING;
});

test('JSON answers report the tokens used in x-usage', async () => {
  gemini = () => sse(['A queue ', 'is FIFO.']);
  const res = await call('/api/explain', { topic: 'queues, one line' });
  assert.equal(res.status, 200);
  const usage = JSON.parse(res.headers.get('x-usage'));
  assert.deepEqual({ calls: usage.calls, in: usage.in, out: usage.out, think: usage.think }, { calls: 1, in: 120, out: 8, think: 30 });
  assert.ok(usage.ms >= 0);
});

test('a model that never answers ends with a clear 504 before the time limit', async () => {
  gemini = (url, init) => new Promise((_, reject) => init.signal.addEventListener('abort', () => reject(init.signal.reason)));
  const t0 = Date.now();
  const res = await call('/api/code-lesson', { topic: 'heaps' }, { 'x-model': 'gemini-a' });
  assert.equal(res.status, 504);
  assert.match((await res.json()).error, /time limit/);
  assert.ok(Date.now() - t0 < 6500, `stopped after ${Date.now() - t0} ms`);
});
