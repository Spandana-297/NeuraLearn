import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

// public/app/progress-stats.js is a browser script; run it in a sandbox.
const ctx = {};
vm.runInNewContext(fs.readFileSync(new URL('../public/app/progress-stats.js', import.meta.url), 'utf8'), ctx);
const P = ctx.ProgressStats;
const at = (d, h = 10) => new Date(`${d}T${String(h).padStart(2, '0')}:00:00`).getTime();
const NOW = at('2026-10-18', 15); // a Sunday afternoon

test('streaks count back from today, or from yesterday before today is done', () => {
  const days = new Set(['2026-10-15', '2026-10-16', '2026-10-17']);
  assert.deepEqual({ ...P.streaks(days, NOW) }, { current: 3, longest: 3 }, 'nothing yet today keeps the streak');
  days.add('2026-10-18');
  assert.equal(P.streaks(days, NOW).current, 4);
  assert.equal(P.streaks(new Set(['2026-10-10', '2026-10-11', '2026-10-12', '2026-10-13', '2026-10-17']), NOW).current, 1);
  assert.equal(P.streaks(new Set(['2026-10-10', '2026-10-11', '2026-10-12', '2026-10-13', '2026-10-17']), NOW).longest, 4);
  assert.deepEqual({ ...P.streaks(new Set(['2026-10-01']), NOW) }, { current: 0, longest: 1 });
  assert.deepEqual({ ...P.streaks(new Set(), NOW) }, { current: 0, longest: 0 });
});

test('active days come from runs, saved days and older lesson records', () => {
  const s = P.activeDays([{ at: at('2026-10-16') }], ['2026-10-14'], { stack: { done: true, at: at('2026-10-12') }, queue: { done: false, at: at('2026-10-11') } });
  assert.deepEqual([...s].sort(), ['2026-10-12', '2026-10-14', '2026-10-16']);
});

test('the activity calendar is whole weeks, Monday first, ending this week', () => {
  const runs = [{ at: at('2026-10-17'), ms: 60000 }, { at: at('2026-10-17', 12), ms: 30000 }, { at: at('2026-10-13'), ms: 1000 }];
  const cells = P.activity(runs, new Set(['2026-10-01']), NOW, 4);
  assert.equal(cells.length, 28);
  assert.equal(new Date(`${cells[0].day}T12:00:00`).getDay(), 1, 'starts on a Monday');
  assert.equal(cells.at(-1).day, '2026-10-18', 'ends on Sunday of this week');
  const sat = cells.find(c => c.day === '2026-10-17');
  assert.equal(sat.count, 2); assert.equal(sat.ms, 90000); assert.equal(sat.level, 4);
  assert.equal(cells.find(c => c.day === '2026-10-01').count, 1, 'a saved day without runs still shows');
  assert.equal(cells.find(c => c.day === '2026-10-13').level, 2);
});

test('this week is compared with last week', () => {
  const runs = [{ at: at('2026-10-12'), ms: 120000 }, { at: at('2026-10-18'), ms: 60000 }, { at: at('2026-10-08'), ms: 600000 }];
  const w = P.week(runs, NOW);
  assert.deepEqual({ ...w.thisWeek }, { lessons: 2, ms: 180000 });
  assert.deepEqual({ ...w.lastWeek }, { lessons: 1, ms: 600000 });
  assert.equal(w.days.length, 7); assert.equal(w.days[0].day, '2026-10-12'); assert.equal(w.days[0].lessons, 1);
});

test('accuracy, lessons to review and CSV export', () => {
  assert.deepEqual({ ...P.accuracy([{ checks: 2, correct: 1 }, { checks: 1, correct: 1 }, { checks: 0, correct: 0 }]) }, { checks: 3, correct: 2, pct: 67 });
  assert.equal(P.accuracy([]).pct, null);
  const prog = { stack: { done: true, right: false, at: 1 }, queue: { done: true, right: true, at: 2 }, bfs: { done: true, right: false, at: 3 }, dfs: { done: false } };
  assert.deepEqual([...P.needsReview(prog, ['stack', 'queue', 'bfs', 'dfs'])], ['bfs', 'stack']);
  const out = P.csv([{ at: at('2026-10-17', 9), algo: 'stack', ms: 90000, checks: 1, correct: 1, input: 'push "1", pop' }], { stack: 'Stack (push and pop)' });
  const lines = out.trim().split('\r\n');
  assert.equal(lines[0], '"date","time","lesson","minutes","checkpoints","correct","input"');
  assert.equal(lines[1], '"2026-10-17","09:00","Stack (push and pop)","1.5","1","1","push ""1"", pop"');
});
