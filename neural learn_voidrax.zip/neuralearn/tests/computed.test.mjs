import test from 'node:test';
import assert from 'node:assert/strict';
import { runAlgorithm, ALGORITHMS } from '../lib/tracers.mjs';
import { validateLesson, validateScenes } from '../lib/lessonSchema.mjs';
import { matchTopic, buildLesson, narrateLesson, answerInterrupt, guardLine } from '../lib/director.mjs';

const TREE = [4, 2, 6, 1, 3, 5, 7];
const randArray = (n, seed) => { let s = seed; return Array.from({ length: n }, () => { s = (s * 9301 + 49297) % 233280; return Math.floor((s / 233280) * 100); }); };

test('tree traversals produce the textbook orders', () => {
  assert.deepEqual(runAlgorithm('inorder', TREE).trace.output, [1, 2, 3, 4, 5, 6, 7]);
  assert.deepEqual(runAlgorithm('preorder', TREE).trace.output, [4, 2, 1, 3, 6, 5, 7]);
  assert.deepEqual(runAlgorithm('postorder', TREE).trace.output, [1, 3, 2, 5, 7, 6, 4]);
  assert.deepEqual(runAlgorithm('levelorder', TREE).trace.output, [4, 2, 6, 1, 3, 5, 7]);
  assert.deepEqual(runAlgorithm('inorder', [8, 3, 10, null, 6, null, 14]).trace.output, [3, 6, 8, 10, 14]);
});

test('every recorded tree step is a consistent state', () => {
  for (const id of ['inorder', 'preorder', 'postorder']) {
    for (const s of runAlgorithm(id, TREE).trace.steps) {
      assert.equal(s.state.stack[s.state.stack.length - 1], s.state.current, `${id}: current node is on top of the stack`);
      assert.ok(s.fact.includes(String(s.state.current)), `${id}: the fact names the current node`);
    }
  }
});

test('sorts match Array.prototype.sort on many inputs, one adjacent move per step', () => {
  for (let seed = 1; seed <= 40; seed++) {
    const input = randArray(2 + (seed % 9), seed);
    const expected = [...input].sort((a, b) => a - b);
    for (const id of ['bubblesort', 'insertionsort', 'selectionsort', 'mergesort']) {
      const run = runAlgorithm(id, input);
      assert.deepEqual(run.trace.output, expected, `${id} sorts ${input}`);
      const last = run.trace.steps[run.trace.steps.length - 1];
      if (last) assert.deepEqual(last.state.arr, expected, `${id}: final frame shows the sorted array`);
      run.trace.steps.forEach(s => assert.equal(s.state.arr.length, input.length));
    }
    let prev = runAlgorithm('bubblesort', input).trace.initial.arr;
    for (const s of runAlgorithm('bubblesort', input).trace.steps) {
      const diff = s.state.arr.map((v, k) => (v !== prev[k] ? k : -1)).filter(k => k >= 0);
      assert.ok(diff.length === 0 || (diff.length === 2 && diff[1] - diff[0] === 1), 'bubble sort only swaps neighbours');
      prev = s.state.arr;
    }
  }
});

test('binary search finds present values and reports missing ones', () => {
  const arr = [2, 5, 8, 12, 16, 23, 38, 56, 72, 91];
  arr.forEach((v, i) => assert.equal(runAlgorithm('binarysearch', arr, v).trace.found, i));
  const miss = runAlgorithm('binarysearch', arr, 40).trace;
  assert.equal(miss.found, -1);
  assert.equal(miss.steps[miss.steps.length - 1].op, 'missing');
  const unsorted = runAlgorithm('binarysearch', [9, 3, 7, 1], 7);
  assert.deepEqual(unsorted.visual.data, [1, 3, 7, 9]);
  assert.match(unsorted.notes.join(' '), /sorted first/);
});

test('topic routing picks the algorithm and reads the input', () => {
  assert.deepEqual(matchTopic('binary search for 23 in [2, 5, 8, 23]'), { id: 'binarysearch', data: [2, 5, 8, 23], target: 23 });
  assert.equal(matchTopic('How does merge sort merge').id, 'mergesort');
  assert.deepEqual(matchTopic('inorder of [8,3,10,null,6]').data, [8, 3, 10, null, 6]);
  assert.equal(matchTopic('level order traversal').id, 'levelorder');
  for (const t of ['what do I need in order to learn calculus', 'insert into a binary search tree', 'photosynthesis']) assert.equal(matchTopic(t), null, t);
});

test('every algorithm builds a valid lesson whose checkpoint answer comes from the trace', () => {
  for (const id of Object.keys(ALGORITHMS)) {
    const lesson = buildLesson({ id });
    assert.deepEqual(validateLesson(lesson), [], id);
    const cp = lesson.scenes.find(s => s.checkpoint).checkpoint;
    assert.ok(cp.options.includes(cp.answer));
    assert.ok(lesson.scenes.some(s => s.id === cp.onWrong && s.kind === 'remedial'));
  }
  const inorder = buildLesson({ id: 'inorder', data: [8, 3, 10, 1, 6, null, 14] });
  assert.equal(inorder.scenes.find(s => s.checkpoint).checkpoint.answer, '1');
  const bubble = buildLesson({ id: 'bubblesort', data: [3, 9, 2, 7] });
  assert.equal(bubble.scenes.find(s => s.checkpoint).checkpoint.answer, '9');
});

test('the validator rejects scenes the AI could get wrong', () => {
  const ctx = { visual: { type: 'tree', data: TREE }, traceLength: 14 };
  const scene = action => [{ id: 'a', kind: 'answer', title: 'x', visual: ctx.visual, beats: [{ say: 'Look here.', action }] }];
  assert.deepEqual(validateScenes(scene({ op: 'traverse', path: [4, 2, 1] }), ctx), []);
  assert.match(validateScenes(scene({ op: 'traverse', path: [4, 1] }), ctx).join(), /not connected/);
  assert.match(validateScenes(scene({ op: 'pulse', target: 99 }), ctx).join(), /node value/);
  assert.match(validateScenes(scene({ op: 'step', index: 14 }), ctx).join(), /step index/);
  assert.match(validateScenes(scene({ op: 'draw', svg: '<svg/>' }), ctx).join(), /action.op/);
  const changed = scene({ op: 'show' }); changed[0].visual = { type: 'tree', data: [4, 2, 6] };
  assert.match(validateScenes(changed, ctx).join(), /lesson's own/);
  const badCp = scene({ op: 'show' }); badCp[0].checkpoint = { q: 'Q?', options: ['1', '2'], answer: '3' };
  assert.match(validateScenes(badCp, ctx).join(), /answer must be one of/);
});

test('narration guard keeps rewording and drops invented values', () => {
  const fact = 'Print 1. Output: [1].';
  assert.equal(guardLine('Node 1 has no left child, so we print 1 now.', fact), 'Node 1 has no left child, so we print 1 now.');
  assert.equal(guardLine('Now we print 4.', fact), null);
  assert.equal(guardLine('<b>Print 1</b>', fact), null);
  assert.equal(guardLine(42, fact), null);
});

test('AI narration replaces lines that pass the fact check only', async () => {
  const lesson = buildLesson({ id: 'inorder' });
  const target = lesson.scenes[1].beats[3]; // "Print 1. Output: [1]."
  const other = lesson.scenes[1].beats[4];
  const model = async () => JSON.stringify({ lines: { [target.id]: 'Since 1 has no left child, it is printed first. Output: [1].', [other.id]: 'Now print 7.' } });
  const before = other.say;
  const { replaced, rejected } = await narrateLesson(lesson, model);
  assert.equal(target.say, 'Since 1 has no left child, it is printed first. Output: [1].');
  assert.equal(other.say, before);
  assert.equal(replaced, 1);
  assert.ok(rejected > 0);
});

test('interrupt answers are validated, retried once, then fall back to replaying real steps', async () => {
  const ask = { algorithm: 'inorder', data: TREE, stepIndex: 2, question: 'why does it go left here?', sceneTitle: 'Left subtree' };
  const good = { scenes: [{ title: 'Why left first', beats: [{ say: 'Inorder must finish the left subtree of 2 first.', action: { op: 'traverse', path: [4, 2, 1] } }, { say: 'So 1 is printed first.', action: { op: 'step', index: 3 } }] }] };
  const bad = { scenes: [{ title: 'Oops', beats: [{ say: 'Jump to 9.', action: { op: 'pulse', target: 9 } }] }] };

  const ok = await answerInterrupt(ask, async () => JSON.stringify(good));
  assert.equal(ok.source, 'ai');
  assert.equal(ok.scenes[0].kind, 'answer');

  let calls = 0;
  const retried = await answerInterrupt(ask, async () => JSON.stringify(++calls === 1 ? bad : good));
  assert.equal(retried.source, 'ai');
  assert.equal(retried.attempts, 2);

  const fallback = await answerInterrupt(ask, async () => JSON.stringify(bad));
  assert.equal(fallback.source, 'replay');
  assert.deepEqual(fallback.scenes[0].beats.map(b => b.action.index), [1, 2, 3]);

  const offline = await answerInterrupt(ask, null);
  assert.equal(offline.source, 'replay');

  await assert.rejects(answerInterrupt({ ...ask, data: [4, 2, 2] }, null), /invalid/);
});

// ---- Graphs, stacks and queues, recursion trees ----
const GRAPH = [[1, 2], [1, 3], [2, 4], [2, 5], [3, 6], [5, 6]];

test('BFS and DFS on a graph produce the textbook visit orders', () => {
  assert.deepEqual(runAlgorithm('bfs', GRAPH, 1).trace.output, [1, 2, 3, 4, 5, 6]);
  assert.deepEqual(runAlgorithm('dfs', GRAPH, 1).trace.output, [1, 2, 4, 5, 6, 3]);
  // A 4-cycle with a tail, started from the middle.
  const g = [[0, 1], [1, 2], [2, 3], [3, 0], [2, 4]];
  assert.deepEqual(runAlgorithm('bfs', g, 2).trace.output, [2, 1, 3, 4, 0]);
  assert.deepEqual(runAlgorithm('dfs', g, 2).trace.output, [2, 1, 0, 3, 4]);
  assert.deepEqual(runAlgorithm('bfs', g, 2).trace.distance, { 0: 2, 1: 1, 2: 0, 3: 1, 4: 1 });
});

test('every recorded graph step is a consistent state', () => {
  for (const id of ['bfs', 'dfs']) {
    const run = runAlgorithm(id, GRAPH, 1), steps = run.trace.steps, edges = run.visual.data;
    for (const s of steps) {
      const e = s.state.edge;
      if (e) assert.ok(edges.some(([a, b]) => (a === e[0] && b === e[1]) || (a === e[1] && b === e[0])), `${id}: checked edge is real`);
      // A search edge always starts from a visited node; DFS records it just before stepping in.
      s.state.treeEdges.forEach(([a, b]) => assert.ok(s.state.visited.includes(a) && (s.state.visited.includes(b) || s.op === 'explore')));
      if (id === 'dfs' && s.op !== 'return') assert.equal(s.state.stack[s.state.stack.length - 1], s.state.current, 'dfs: current is on top of the call stack');
    }
    assert.equal(steps[steps.length - 1].state.treeEdges.length, 5, `${id}: a spanning tree has V - 1 edges`);
    // Every edge is looked at from both ends exactly once.
    assert.equal(steps.filter(s => s.state.edge).length, 2 * edges.length, `${id}: 2E edge checks`);
  }
});

test('graph inputs are checked before running', () => {
  assert.match(runAlgorithm('bfs', [[1, 2], [3, 4]]).notes.join(' '), /connected/);
  assert.match(runAlgorithm('dfs', [[1, 1]]).notes.join(' '), /itself/);
  const off = runAlgorithm('dfs', [[5, 7], [7, 9]], 2);
  assert.equal(off.visual.start, 5);
  assert.match(off.notes.join(' '), /not in the graph/);
});

test('stack and queue run the same operations as LIFO and FIFO', () => {
  const ops = ['push 3', 'push 7', 'push 5', 'pop', 'push 9', 'pop', 'pop'];
  const st = runAlgorithm('stack', ops).trace;
  assert.deepEqual(st.output, [5, 9, 7]);
  assert.deepEqual(st.final, [3]);
  const q = runAlgorithm('queue', ops.map(o => o.replace('push', 'enqueue').replace('pop', 'dequeue'))).trace;
  assert.deepEqual(q.output, [3, 7, 5]);
  assert.deepEqual(q.final, [9]);
  // One step per operation, and each item keeps the id of the operation that added it.
  assert.equal(st.steps.length, ops.length);
  assert.deepEqual(st.steps[4].state.items, [{ id: 0, v: 3 }, { id: 1, v: 7 }, { id: 4, v: 9 }]);
  const under = runAlgorithm('stack', ['push 2', 'pop', 'pop', 'peek']).trace.steps;
  assert.deepEqual(under.map(s => s.op), ['add', 'remove', 'underflow', 'underflow']);
  assert.match(runAlgorithm('queue', ['pop']).notes.join(' '), /default/);
});

test('fib recursion tree matches the real call tree', () => {
  const run = runAlgorithm('fibonacci', [5]);
  assert.equal(run.trace.output, 5);
  assert.equal(run.visual.calls.length, 15);
  assert.equal(run.visual.calls.filter(c => c.arg === 2).length, 3);
  assert.equal(run.trace.steps.length, 15 + 7, 'one step per call plus one return per non-base call');
  const s4 = runAlgorithm('fibonacci', [4]).trace.steps;
  assert.deepEqual(s4.filter(s => s.op === 'base' || s.op === 'return').map(s => s.state.ret[s.state.current]), [1, 0, 1, 1, 2, 1, 0, 1, 3]);
  s4.forEach(s => assert.equal(s.state.stack[s.state.stack.length - 1], s.state.current));
  assert.match(runAlgorithm('fibonacci', [9]).notes.join(' '), /2 to 6/);
});

test('topic routing reads graphs, operations and fib(n)', () => {
  assert.deepEqual(matchTopic('BFS on graph 1-2, 1-3, 2-4 from 2'), { id: 'bfs', data: [[1, 2], [1, 3], [2, 4]], target: 2 });
  assert.deepEqual(matchTopic('dfs on a graph'), { id: 'dfs', data: undefined, target: undefined });
  assert.equal(matchTopic('depth first search').id, 'dfs');
  assert.equal(matchTopic('bfs of a binary tree').id, 'levelorder');
  assert.equal(matchTopic('dfs on a tree').id, 'preorder');
  assert.deepEqual(matchTopic('stack: push 4, push 8, pop, peek'), { id: 'stack', data: ['push 4', 'push 8', 'pop', 'peek'] });
  assert.deepEqual(matchTopic('queue [1, 2, 3]').data, ['enqueue 1', 'enqueue 2', 'enqueue 3', 'dequeue', 'dequeue', 'dequeue']);
  assert.deepEqual(matchTopic('recursion tree for fib(5)'), { id: 'fibonacci', data: [5] });
  assert.equal(matchTopic('merge sort recursion tree').id, 'mergesort');
});

test('new visuals build valid lessons with checkpoints computed from the trace', () => {
  assert.equal(buildLesson({ id: 'bfs' }).scenes.find(s => s.checkpoint).checkpoint.answer, '3');
  assert.equal(buildLesson({ id: 'dfs' }).scenes.find(s => s.checkpoint).checkpoint.answer, '4');
  assert.equal(buildLesson({ id: 'stack' }).scenes.find(s => s.checkpoint).checkpoint.answer, '5');
  assert.equal(buildLesson({ id: 'queue' }).scenes.find(s => s.checkpoint).checkpoint.answer, '3');
  assert.equal(buildLesson({ id: 'fibonacci', data: [5] }).scenes.find(s => s.checkpoint).checkpoint.answer, '3');
  assert.equal(buildLesson({ id: 'stack', data: ['push 1', 'push 2'] }).scenes.find(s => s.checkpoint).checkpoint.answer, '2');
  // Odd inputs still produce valid lessons.
  const odd = [
    { id: 'bfs', data: [[0, 1]] }, { id: 'dfs', data: [[0, 1], [1, 2], [2, 3]], target: 3 }, { id: 'bfs', data: [[1, 2], [1, 3], [1, 4], [1, 5]] },
    { id: 'stack', data: ['push 1'] }, { id: 'stack', data: ['pop', 'push 2', 'push 2'] }, { id: 'queue', data: ['enqueue 4', 'peek', 'dequeue', 'dequeue'] },
    { id: 'fibonacci', data: [2] }, { id: 'fibonacci', data: [3] }, { id: 'fibonacci', data: [6] },
  ];
  for (const m of odd) {
    const lesson = buildLesson(m);
    assert.deepEqual(validateLesson(lesson), [], JSON.stringify(m));
    const cp = lesson.scenes.find(s => s.checkpoint).checkpoint;
    assert.ok(cp.options.length >= 2 && cp.options.includes(cp.answer), JSON.stringify(m));
  }
});

test('the validator checks graph edges, call edges and stack targets', () => {
  const scene = (visual, action) => [{ id: 'a', kind: 'answer', title: 'x', visual, beats: [{ say: 'Look here.', action }] }];
  const g = { type: 'graph', data: GRAPH }, gctx = { visual: g, traceLength: 19 };
  assert.deepEqual(validateScenes(scene(g, { op: 'traverse', path: [1, 3, 6, 5] }), gctx), []);
  assert.match(validateScenes(scene(g, { op: 'traverse', path: [1, 4] }), gctx).join(), /not connected/);
  assert.match(validateScenes(scene(g, { op: 'pulse', target: 7 }), gctx).join(), /node value in the graph/);
  const r = { type: 'recursion', data: [4] }, rctx = { visual: r, traceLength: 13 };
  assert.deepEqual(validateScenes(scene(r, { op: 'traverse', path: [0, 1, 2, 3] }), rctx), []);
  assert.match(validateScenes(scene(r, { op: 'traverse', path: [0, 2] }), rctx).join(), /not connected/);
  assert.match(validateScenes(scene(r, { op: 'highlight', targets: [9] }), rctx).join(), /call id/);
  const st = { type: 'stack', data: ['push 1', 'pop'] }, sctx = { visual: st, traceLength: 2 };
  assert.deepEqual(validateScenes(scene(st, { op: 'pulse', target: 0 }), sctx), []);
  assert.match(validateScenes(scene(st, { op: 'pulse', target: 2 }), sctx).join(), /operation index/);
  assert.match(validateScenes(scene(st, { op: 'traverse', path: [0, 1] }), sctx).join(), /not available/);
});

test('interrupts on a graph lesson recompute with the lesson start node and check graph edges', async () => {
  const ask = { algorithm: 'dfs', data: GRAPH, target: 3, stepIndex: 4, question: 'why go deeper here?' };
  let prompt = '';
  const good = { scenes: [{ title: 'Going deep', beats: [{ say: 'From 3 the search dives to 1 and then 2.', action: { op: 'traverse', path: [3, 1, 2] } }] }] };
  const ok = await answerInterrupt(ask, async (sys, user) => { prompt = user; return JSON.stringify(good); });
  assert.equal(ok.source, 'ai');
  assert.match(prompt, /start node 3/);
  assert.match(prompt, /Targets: a node value in the graph/);
  const bad = { scenes: [{ title: 'Shortcut', beats: [{ say: 'Jump from 3 to 4.', action: { op: 'traverse', path: [3, 4] } }] }] };
  assert.equal((await answerInterrupt(ask, async () => JSON.stringify(bad))).source, 'replay');
});

// ---- Curriculum and the lesson service behind the app's screens ----
test('the catalog covers every algorithm once, and every example builds a clean lesson', async () => {
  const { catalog, parseInput, formatInput } = await import('../lib/catalog.mjs');
  const { computedLesson } = await import('../lib/lessonService.mjs');
  const ids = catalog().modules.flatMap(m => m.topics.map(t => t.id));
  assert.deepEqual([...ids].sort(), Object.keys(ALGORITHMS).sort());
  for (const t of catalog().modules.flatMap(m => m.topics)) {
    t.prereq.forEach(p => assert.ok(ids.indexOf(p) < ids.indexOf(t.id), `${t.id}: prerequisite ${p} comes earlier`));
    for (const ex of t.examples) {
      const r = await computedLesson({ algorithm: t.id, input: ex.text, target: ex.target });
      assert.deepEqual(r.lesson.notes, [], `${t.id} / ${ex.label}`);
      assert.deepEqual(parseInput(t.id, r.input.text).data, r.lesson.visual.data, `${t.id}: formatInput round-trips`);
    }
  }
  assert.deepEqual(parseInput('inorder', '8, 3, null, 1').data, [8, 3, null, 1]);
  assert.deepEqual(parseInput('bfs', '1-2, 2 3, 3->4').data, [[1, 2], [2, 3], [3, 4]]);
  assert.deepEqual(parseInput('stack', 'push(3), pop, peek').data, ['push 3', 'pop', 'peek']);
  assert.match(parseInput('queue', 'push 3').error, /not a queue operation/);
  assert.match(parseInput('bubblesort', '3, x').error, /"x" is not a number/);
  assert.equal(parseInput('fibonacci', '').data, undefined);
  assert.deepEqual(formatInput({ type: 'graph', data: [[1, 2]], start: 1 }), { text: '1-2', target: '1' });
});

test('the lesson service accepts free text or the topic page input, and rejects bad input', async () => {
  const { computedLesson } = await import('../lib/lessonService.mjs');
  assert.equal((await computedLesson({ topic: 'photosynthesis' })).supported, false);
  const fromText = await computedLesson({ topic: 'dfs on graph 1-2, 2-3 from 3' });
  assert.deepEqual(fromText.input, { text: '1-2, 2-3', target: '3' });
  const fromForm = await computedLesson({ algorithm: 'dfs', input: '1-2, 2-3', target: '3' });
  assert.equal(fromForm.lesson.lessonId, fromText.lesson.lessonId);
  await assert.rejects(computedLesson({ algorithm: 'nope' }), /Unknown algorithm/);
  await assert.rejects(computedLesson({ algorithm: 'stack', input: 'push x' }), e => e.status === 400);
  await assert.rejects(computedLesson({ topic: '' }), /Topic is required/);
  let asked = 0;
  const model = { isConfigured: () => true, currentModel: () => 'mock', modelCall: async () => { asked++; return JSON.stringify({ lines: {} }); } };
  const narrated = await computedLesson({ algorithm: 'stack', narrate: 'ai' }, model);
  assert.equal(narrated.narration.source, 'ai');
  assert.equal(asked, 1);
});

// ---- Natural voice ----
test('voice audio is split into lines at the real pauses', async () => {
  const { segment } = await import('../lib/tts.mjs');
  // Synthetic speech: 1.5 s tone, 0.5 s silence, 1.0 s tone, 0.4 s silence, 2.0 s tone.
  const rate = 24000, parts = [[1.5, 1], [0.5, 0], [1.0, 1], [0.4, 0], [2.0, 1]];
  const pcm = Buffer.concat(parts.map(([sec, on]) => { const b = Buffer.alloc(Math.round(sec * rate) * 2); if (on) for (let i = 0; i < b.length / 2; i++) b.writeInt16LE(Math.round(Math.sin(i / 6) * 8000), i * 2); return b; }));
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + pcm.length, 4); h.write('WAVE', 8); h.write('fmt ', 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22);
  h.writeUInt32LE(rate, 24); h.writeUInt32LE(rate * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34); h.write('data', 36); h.writeUInt32LE(pcm.length, 40);
  const segs = segment(Buffer.concat([h, pcm]), ['A first line of speech.', 'A short one.', 'And a much longer closing line here.']);
  assert.equal(segs.length, 3);
  assert.ok(Math.abs(segs[0][1] - 1.75) < 0.1, `first cut at ${segs[0][1]}`);
  assert.ok(Math.abs(segs[1][1] - 3.2) < 0.1, `second cut at ${segs[1][1]}`);
  assert.ok(Math.abs(segs[2][1] - 5.4) < 0.05);
});

test('voice requests read both response shapes, cache, and report rate limits', async () => {
  const { synthesize } = await import('../lib/tts.mjs');
  const cfg = { enabled: true, key: 'k', base: 'https://x.test', model: 'm', voice: 'Kore', rpm: 3 };
  const wav = Buffer.concat([Buffer.from('RIFF'), Buffer.alloc(40), Buffer.alloc(4800)]).toString('base64');
  let calls = 0;
  const ok = async (url, init) => { calls++; assert.match(url, /\/interactions$/); assert.match(JSON.parse(init.body).input[0].content[0].text, /One\.\n\nTwo\./); return { ok: true, json: async () => ({ steps: [{ type: 'model_output', content: [{ type: 'audio', data: wav }] }] }) }; };
  const r = await synthesize(['One.', 'Two.'], cfg, ok);
  assert.equal(r.segments.length, 2);
  await synthesize(['One.', 'Two.'], cfg, ok);
  assert.equal(calls, 1, 'second request is served from the cache');
  const sdk = await synthesize('Three.', cfg, async () => ({ ok: true, json: async () => ({ output_audio: { data: wav } }) }));
  assert.equal(sdk.segments.length, 1);
  const limited = async () => ({ ok: false, status: 429, json: async () => ({ error: { message: 'Rate limit exceeded (limit: 3 requests per minute on Free Tier). Please retry in 32s.' } }) });
  await assert.rejects(synthesize('Four.', cfg, limited), e => e.status === 429 && e.retryAfter === 32 && !e.daily);
  await assert.rejects(synthesize('Five.', { ...cfg, enabled: false }), e => e.status === 503);
  await assert.rejects(synthesize(['x'.repeat(500)], cfg, ok), e => e.status === 413);
});

// ---- Background fact check ----
test('fact check rules catch bad arithmetic, wrong complexities and new numbers in the lecture', async () => {
  const { ruleCheck } = await import('../lib/factcheck.mjs');
  const found = ruleCheck('So 7 + 5 = 13, while 6 x 4 = 24. Bubble sort runs in O(n log n) time in the worst case. Merge sort is O(n log n). Binary search takes O(log n) time. Quick sort is O(n^2) in the worst case.', ['We now compare 9 and 11.', 'Merge sort is fast.']);
  assert.deepEqual(found.map(c => c.verdict), ['wrong', 'wrong', 'doubt']);
  assert.equal(found[0].fix, '7 + 5 = 12');
  assert.match(found[1].quote, /^Bubble sort/);
  assert.equal(found[2].quote, 'We now compare 9 and 11.');
  assert.deepEqual(ruleCheck('Insertion sort is O(n) in the best case and O(n²) in the worst case. BFS runs in O(V + E).'), []);
  assert.deepEqual(ruleCheck('Merge sort needs O(n) extra space.'), [], 'space claims are not time claims');
});

test('fact check keeps a model verdict of "wrong" only when a second check agrees', async () => {
  const { factCheck } = await import('../lib/factcheck.mjs');
  let calls = 0;
  const model = async system => {
    calls++;
    if (/second, independent/.test(system)) return JSON.stringify({ answers: [{ n: 1, wrong: true }, { n: 2, wrong: false }] });
    return JSON.stringify({ claims: [
      { quote: 'Dijkstra works with negative edge weights.', verdict: 'wrong', fix: 'It needs non-negative weights.' },
      { quote: 'A queue is FIFO.', verdict: 'wrong', fix: 'x' },
      { quote: 'This sentence is not in the text.', verdict: 'wrong' },
      { quote: 'BFS uses a queue.', verdict: 'ok' },
    ] });
  };
  const r = await factCheck({ topic: 'graphs', text: 'Dijkstra works with negative edge weights. A queue is FIFO. BFS uses a queue. Also 2 + 2 = 5.' }, model);
  assert.equal(calls, 2);
  const by = q => r.claims.find(c => c.quote.startsWith(q));
  assert.equal(by('Dijkstra').verdict, 'wrong');
  assert.equal(by('A queue').verdict, 'doubt');
  assert.equal(by('BFS').verdict, 'ok');
  assert.equal(by('2 + 2').source, 'rule');
  assert.ok(!r.claims.some(c => c.quote.startsWith('This sentence')), 'claims the text never made are dropped');
  const offline = await factCheck({ text: 'Also 2 + 2 = 5.' }, null);
  assert.equal(offline.reviewed, 'rules only');
  const failing = await factCheck({ text: 'Also 2 + 2 = 5.' }, async () => { throw new Error('busy'); });
  assert.match(failing.reviewed, /model check failed: busy/);
  assert.equal(failing.counts.wrong, 1);
});

test('fact check matches quotes against markdown and keeps code untouched for the reviewer', async () => {
  const { factCheck } = await import('../lib/factcheck.mjs');
  let seen = '';
  const text = 'A **hash table** maps keys to values.\n\n```c\nstruct Node { char *key; struct Node *next; };\n```';
  const r = await factCheck({ topic: 'hashing', text }, async (system, user) => {
    if (/second, independent/.test(system)) return '{"answers":[]}';
    seen = user;
    return JSON.stringify({ claims: [{ quote: 'A hash table maps keys to values.', verdict: 'ok' }] });
  });
  assert.match(seen, /char \*key; struct Node \*next;/, 'pointer asterisks reach the reviewer');
  assert.doesNotMatch(seen, /\*\*hash table\*\*/, 'bold markers are removed');
  assert.equal(r.claims.length, 1, 'a plain-text quote of bold text is accepted');
});

// ---- Model choice and fallback ----
test('the chosen model is tried first, then the others in order', async () => {
  const { modelList, modelOrder, withModelChoice, noteModel, modelReport } = await import('../lib/models.mjs');
  const env = { GEMINI_MODELS: 'gemini-3.5-flash,gemini-3.8-flash,gemini-flash-lite-latest' };
  const gemini = modelList(env).filter(m => m.provider === 'gemini');
  assert.equal(gemini.length, 3);
  assert.equal(gemini[2].label, 'Gemini Flash-Lite');
  // OpenAI and Grok are listed in the menu but never tried without their keys.
  assert.ok(modelList(env).some(m => m.provider === 'openai' && !m.configured));
  assert.deepEqual(modelOrder(env), ['gemini-3.5-flash', 'gemini-3.8-flash', 'gemini-flash-lite-latest']);
  assert.deepEqual(modelOrder({ ...env, GEMINI_API_KEY: 'g', OPENAI_API_KEY: 'o' }).slice(3), ['openai:gpt-5.4-mini']);
  await withModelChoice('gemini-flash-lite-latest', async () => {
    assert.deepEqual(modelOrder(env), ['gemini-flash-lite-latest', 'gemini-3.5-flash', 'gemini-3.8-flash']);
    noteModel('gemini-3.5-flash', ['gemini-flash-lite-latest']);
    assert.deepEqual(modelReport().skipped, ['gemini-flash-lite-latest']);
  });
  await withModelChoice('not-a-model', async () => assert.equal(modelOrder(env)[0], 'gemini-3.5-flash'));
});

// ---- Phase 4 guardrails ----
test('known facts catch common wrong claims and leave correct ones alone', async () => {
  const { knownFacts } = await import('../lib/facts.mjs');
  const wrong = ['A stack is FIFO, so the first item added comes out first.', 'TCP uses a two-way handshake to open a connection.', 'BFS uses a stack to track nodes.', 'Binary search works on any unsorted array.', "Ohm's law says V = I / R.", 'In a hash table, lookup is O(n) on average.', 'Photosynthesis releases carbon dioxide.'];
  const right = ['A queue is FIFO.', 'A stack is LIFO, unlike a queue which is FIFO.', 'TCP closes with a four-way handshake using FIN.', 'Binary search only works on sorted arrays.', 'Hash table lookup is O(1) on average and O(n) in the worst case.', 'BFS uses a queue, unlike DFS which uses a stack.'];
  for (const s of wrong) assert.equal(knownFacts(s)[0]?.verdict, 'wrong', s);
  for (const s of right) assert.equal(knownFacts(s).length, 0, s);
});

test('PDF lecture lines that are not in the document are flagged', async () => {
  const { factCheck } = await import('../lib/factcheck.mjs');
  const doc = 'The mitochondria is the powerhouse of the cell. It produces ATP through cellular respiration, using oxygen and glucose. The inner membrane is folded into cristae.';
  const lines = ['The mitochondria makes ATP by cellular respiration with glucose and oxygen.', 'Quantum chromodynamics explains quark confinement through gluon exchange interactions strongly.'];
  const r = await factCheck({ text: doc, lines, source: true });
  assert.deepEqual(r.claims.map(c => c.quote), [lines[1]]);
  assert.equal((await factCheck({ text: doc, lines })).claims.length, 0, 'only PDF lectures get the document check');
});

test('the fact check is reviewed by a different model than the writer', async () => {
  const { reviewerFor } = await import('../lib/models.mjs');
  const env = { GEMINI_API_KEY: 'g', GEMINI_MODELS: 'gemini-3.5-flash,gemini-flash-lite-latest', OPENAI_API_KEY: 'o' };
  assert.equal(reviewerFor('gemini-3.5-flash', env), 'openai:gpt-5.4-mini', 'another provider first');
  assert.equal(reviewerFor('openai:gpt-5.4-mini', env), 'gemini-3.5-flash');
  assert.equal(reviewerFor('gemini-3.5-flash', { GEMINI_API_KEY: 'g', GEMINI_MODELS: 'gemini-3.5-flash,gemini-flash-lite-latest' }), 'gemini-flash-lite-latest', 'else another model');
  assert.equal(reviewerFor('unknown-model', env), null);
});

test('during a fact check the writer is only tried after every other model', async () => {
  const { modelOrder, withModelChoice, preferModel } = await import('../lib/models.mjs');
  const env = { GEMINI_API_KEY: 'g', GEMINI_MODELS: 'gemini-3.5-flash,gemini-3.8-flash,gemini-flash-lite-latest' };
  await withModelChoice(null, async () => {
    preferModel('gemini-3.5-flash', 'gemini-3.8-flash');
    assert.deepEqual(modelOrder(env), ['gemini-3.5-flash', 'gemini-flash-lite-latest', 'gemini-3.8-flash']);
  });
});

// ---- Sources for AI answers ----
test('sources are rated against the trusted list', async () => {
  const { trustOf, domainOf } = await import('../lib/sources.mjs');
  for (const d of ['mit.edu', 'ocw.mit.edu', 'iitb.ac.in', 'en.wikipedia.org', 'developer.mozilla.org', 'datatracker.ietf.org', 'nist.gov', 'arxiv.org', 'www.britannica.com', 'cs.cmu.edu']) assert.equal(trustOf(d), 'trusted', d);
  for (const d of ['geeksforgeeks.org', 'www.khanacademy.org', 'cp-algorithms.com']) assert.equal(trustOf(d), 'reputable', d);
  for (const d of ['randomblog.net', 'medium.com', 'quora.com', 'edu.example.com', 'fakewikipedia.org', '']) assert.equal(trustOf(d), 'other', d || '(empty)');
  assert.equal(domainOf('https://www.Wikipedia.org/wiki/Stack'), 'wikipedia.org');
});

test('grounding metadata becomes numbered sources, best first, with backed statements', async () => {
  const { buildSources } = await import('../lib/sources.mjs');
  const meta = {
    webSearchQueries: ['stack data structure'],
    groundingChunks: [{ web: { uri: 'https://redirect/1', title: 'someblog.net' } }, { web: { uri: 'https://redirect/2', title: 'en.wikipedia.org' } }, { web: { uri: 'https://redirect/3', title: 'en.wikipedia.org' } }, { web: { uri: 'javascript:alert(1)', title: 'evil.com' } }],
    groundingSupports: [{ segment: { text: 'A stack is last in, first out.' }, groundingChunkIndices: [0, 1] }, { segment: { text: 'Push adds to the top.' }, groundingChunkIndices: [0] }, { segment: { text: 'Bad link only.' }, groundingChunkIndices: [3] }],
    searchEntryPoint: { renderedContent: '<div>chips</div>' },
  };
  const r = buildSources(meta, 'A stack is last in, first out. Push adds to the top.');
  assert.deepEqual(r.sources.map(s => [s.n, s.domain, s.trust]), [[1, 'en.wikipedia.org', 'trusted'], [2, 'someblog.net', 'other']], 'one entry per site, trusted first, unsafe links dropped');
  assert.deepEqual(r.claims.map(c => [c.text, c.sources, c.trust]), [['A stack is last in, first out.', [1, 2], 'trusted'], ['Push adds to the top.', [2], 'other']]);
  assert.equal(r.counts.trusted, 1); assert.equal(r.widget, '<div>chips</div>');
  assert.equal(buildSources({ groundingChunks: [] }, 'x'), null);
});

test('citation markers are found per sentence and removed outside code', async () => {
  const { citedClaims, stripCites, keywords, bestPassages } = await import('../lib/retrieve.mjs');
  const list = [{ n: 1 }, { n: 2 }];
  const text = 'TCP uses a three-way handshake [1]. The client sends SYN, the server SYN-ACK, then ACK.[1][2] An analogy: two people greeting. A bogus one [7].\n```c\nint x = a[1];\n```';
  const r = citedClaims(text, list);
  assert.deepEqual(r.claims.map(c => [c.text, c.sources]), [['TCP uses a three-way handshake.', [1]], ['The client sends SYN, the server SYN-ACK, then ACK.', [1, 2]]]);
  assert.equal(stripCites(text), 'TCP uses a three-way handshake. The client sends SYN, the server SYN-ACK, then ACK. An analogy: two people greeting. A bogus one.\n```c\nint x = a[1];\n```');
  assert.deepEqual(keywords('How does the TCP three-way handshake work? Two sentences.'), ['tcp', 'three-way', 'handshake']);
  const doc = 'Intro paragraph about stacks and how they are used in computing widely.\n== History ==\nA long history paragraph that mentions nothing relevant at all to the question here.\n== Operations ==\nPush adds an element to the top of the stack and pop removes the top element of the stack.\n== See also ==\nQueue data structure is a related thing that should never be included in passages.';
  const p = bestPassages(doc, ['push', 'pop', 'stack']);
  assert.match(p, /^Intro paragraph/); assert.match(p, /Push adds/); assert.doesNotMatch(p, /History|Queue data structure/);
});
