# NeuraLearn: Handoff

NeuraLearn teaches data structures and algorithms with lessons whose animations are **computed, not hallucinated**: the server runs the real algorithm on the student's input, records every step, and the browser animates those recorded steps with voice, subtitles and a teacher's pointer. An AI tutor covers every other topic with generated visual lectures, checked by a background fact check.

- Live site (Netlify): https://storied-churros-164bf2.netlify.app/ (the app is at `/app`)
- Code: `C:\Users\mdaff\Mystara\neuralearn` (not a git repository yet)
- Run locally: `node server.mjs`, then open http://127.0.0.1:4173/app
- Tests: `node --test` (29 tests)

Each section says what is **built** today and, where relevant, what is **proposed** but not built.

---

## 1. What has been built

| Area | What exists |
|---|---|
| Computed lessons | 14 algorithms across 6 visualizers: tree traversals (inorder, preorder, postorder, level order), binary search, bubble/insertion/selection/merge sort, BFS and DFS on graphs, stack and queue operations, fib(n) recursion tree. Built from the student's own input. |
| Lesson flow | Library → topic page (choose input, lesson plan, preview) → lesson player → summary screen. |
| Lesson player | Whiteboard / Code / Notes tabs; teacher's pointer stick; word-by-word subtitles; scene cards; seek bar with elapsed/total time; Back/Next; keyboard shortcuts; drawing tools (pen, eraser, text, circle, colours); zoom and full screen; steps panel; key points. |
| Interactivity | Interrupt the professor: a question pauses the lesson and new animated scenes, built from the same trace, are inserted at that step. Checkpoint questions whose answers come from the trace; a wrong answer opens a remedial scene. Click anything on the board to ask about it. |
| AI tutor | Any topic: streamed written answer, key points written on the board while the lecture is generated, then a generated animated lecture in parts. Pointer and subtitles also work in these lectures. |
| PDF tutor | Upload a text PDF; summary first, then a lecture per section (see section 6). |
| Fact check | Verified / Unverified toggle. Rule checks plus two independent AI checks (see section 8). |
| Voices | 12 natural Gemini TTS voices × 4 speaking styles, plus every voice installed on the device; automatic fallback to the device voice. |
| Models | Three Gemini models with automatic fallback when one is busy; OpenAI and Grok can be added with keys. |
| Pages | Home dashboard, New Lesson, My Library, Progress, PDF Tutor, Settings, dark mode, notifications bell, profile name. |
| Hosting | Netlify (current). A Vercel setup also exists but is unused. |

---

## 2. Tech stack

| Layer | Technology |
|---|---|
| Frontend | Plain HTML, CSS and JavaScript. No framework, no build step, no npm packages. |
| Rendering | Hand-written SVG renderers for each visualizer (`public/app/computed.js`). Generated AI lectures run in a sandboxed `<iframe>` (`sandbox="allow-scripts"`, no same-origin access). |
| PDF parsing | pdf.js, loaded from the jsDelivr CDN in the browser. |
| Backend | Node.js 20+, ES modules, built-in `http` module only (`server.mjs`). No npm dependencies. |
| AI text | Google Gemini REST API (default: Gemini 3.5 Flash, 3.8 Flash, Flash-Lite). Optional: OpenAI, xAI Grok, any OpenAI-compatible endpoint, or local Ollama. |
| AI voice | Gemini TTS (Interactions API); browser `speechSynthesis` as fallback. |
| Hosting | Netlify: `public/` is the static site, `netlify/functions/api.mjs` is one function that serves every `/api/*` route with the same handler as `server.mjs`. |
| Tests | Node's built-in test runner (`node --test`). |

---

## 3. Frontend (`public/app/`)

| File | Responsibility |
|---|---|
| `index.html` | All screens and the icon sprite. Screens are shown and hidden by the router. |
| `styles.css` | All styles. The current design is the last block, "Dashboard design" (navy sidebar, indigo accent, light default, dark mode via `data-theme="dark"`). |
| `shell.js` | Router (`#/`, `#/new`, `#/library`, `#/progress`, `#/pdf`, `#/learn/<id>`, `#/lesson/<id>`, `#/done/<id>`, `#/tutor`), home/library/progress/topic/summary pages, top bar (search, model menu, dark mode, notifications, profile), progress storage, streak. |
| `tour.js` | Guided tours, one per page (Home, AI tutor, PDF tutor, Library, Progress, topic setup, lesson player, New lesson): a spotlight, the lesson's wooden pointer tapping each part, and a step card saying what it does and how to use it. Each page's tour plays the first time that page opens (`shell.js` `show()` calls `Tour.maybeStart(page)`), remembered per page in `nl.tour.<page>`. The ? button in the top bar and the profile menu replay the current page's tour. Keyboard: arrows, Esc. A playing lesson pauses during its tour. On phones the card docks to the screen edge and sidebar steps point at the ☰ button. Steps live in `TOURS` at the top of the file. |
| `computed.js` | Plays computed lessons: the visualizers, the teacher's pointer, subtitles, checkpoints, interrupts, scene cards. Emits `computed:load`, `computed:beat`, `computed:checkpoint`, `computed:finish` events. |
| `boardtools.js` | Whiteboard / Code / Notes tabs, zoom, full screen, drawing tools, steps panel, key points, timeline and seek, scene arrows, mute. |
| `codesamples.js` | Python code for each algorithm and which line each trace step runs (Code tab). |
| `app.js` | AI tutor: chat, streamed explanations, board notes, lecture parts queue, PDF tutor, lecture subtitles and voice. |
| `boardkit.js` | Injected into every generated lecture so it gets the pointer (`window.NL.point(el)` plus an automatic fallback). |
| `voice.js` | Voice menus, natural voice (scene-level requests paced to the rate limit), device voice ranking, pause/resume. |
| `factcheck.js` | Shows fact-check results under answers; Verified / Unverified toggle. |
| `models.js` | Adds the chosen model (`x-model` header) to every API request; reports when a busy model was skipped. |

The marketing landing page is `public/index.html` (still the older purple design).

---

## 4. Backend

### Files

| File | Responsibility |
|---|---|
| `server.mjs` | Local server: API routes, static files, model calls (streaming, model fallback), caches. Exports `requestHandler` (used by the Vercel functions). |
| `lib/tracers.mjs` | Runs each algorithm and records one step per operation: `{op, fact, phase, state}`. The only source of animation frames. |
| `lib/director.mjs` | Routes topics to algorithms, cuts traces into scenes, writes intro/misconception/remedial/recap scenes and checkpoints from the trace, AI narration with a number guard, interrupt answers. |
| `lib/lessonSchema.mjs` | Validates every scene and action (targets must exist, paths must follow real edges, steps must exist). |
| `lib/catalog.mjs` | The curriculum: modules, topics, descriptions, examples, prerequisites, input formats and parsing. |
| `lib/lessonService.mjs` | Builds a computed lesson from free text or the topic page input (shared by both hosts). |
| `lib/factcheck.mjs` | Fact check: rules, independent reviewer, second opinion. |
| `lib/tts.mjs` | Gemini TTS: voices, styles, splitting scene audio into lines at the pauses. |
| `lib/models.mjs` | Configured models and the order to try them in. |
| `lib/model-provider.mjs` | Calls Gemini, OpenAI, Grok or a compatible endpoint, with fallback. |
| `lib/cache.mjs` | Small in-memory cache for repeated AI answers. |
| `netlify/functions/api.mjs`, `lib/netlify.mjs` | One Netlify function for every `/api/*` route. `lib/netlify.mjs` turns Netlify's web request into the request/response objects `server.mjs` expects and streams the response back, so Netlify runs exactly the local code. It also gives each request a 55 s budget (`NL_TIME_LIMIT_MS`): model calls stop trying new models before Netlify's 60 s cut-off and return a clear "try again" error (504). |
| `api/*.js`, `lib/vercel.mjs`, `vercel.json` | Vercel setup (unused). |

### API endpoints

| Method and path | Purpose |
|---|---|
| `GET /api/health` | Provider, configured models, voice availability, voices and styles. |
| `GET /api/catalog` | The curriculum for the library and topic pages. |
| `POST /api/computed-lesson` | `{topic}` or `{algorithm, input, target}` → a computed lesson (trace + scenes). `narrate: 'ai'` also asks the model to reword the lines. |
| `POST /api/interrupt` | A question at a step → 1 to 3 validated scenes, or a replay of the real steps. |
| `POST /api/ocr` | `{image}` (one JPEG page, base64, under about 700 KB) returns `{text, model}`: Gemini transcribes a scanned PDF page. |
| `POST /api/sources` | `{topic, text}` returns numbered sources rated trusted / reputable / other, found with Google Search for an answer written without searching. |
| `GET /api/config` | `{accounts: {url, anonKey} | null}`: Supabase project URL and publishable key, when accounts are set up. |
| `POST /api/explain` | AI tutor answer. `stream: true` returns NDJSON (`{t}` pieces, then `{done}`), locally and on Netlify. |
| `POST /api/code-lesson` | Generates a lecture as a standalone HTML program (`visualize: true` for chat answers, `pdf: true` for PDF sections). |
| `POST /api/factcheck` | `{topic, text, lines?, rulesOnly?}` → claims with verdicts and corrections. |
| `POST /api/tts` | `{lines, voice, style}` → one WAV file plus an `x-segments` header with each line's start and end. |
| `POST /api/lesson`, `/api/ask` | Older engine; still served. |

### API keys and settings (environment variables)

Keys live only on the server: in `.env` locally, and in Netlify's environment variables in production. **Never put a key in the frontend or commit `.env`.** The Gemini key was pasted into a chat during development, so create a new one in Google AI Studio and replace it.

| Variable | Used for |
|---|---|
| `GEMINI_API_KEY` | Gemini text and TTS (required for AI features). |
| `LLM_PROVIDER` | `gemini` (default), `openai`, `xai`, `openai-compatible`, `ollama`. |
| `GEMINI_MODEL`, `GEMINI_MODELS` | Default model and the fallback list, e.g. `gemini-3.5-flash,gemini-3.8-flash,gemini-flash-lite-latest`. **Not set on Netlify yet**, so production only has one model and no fallback. |
| `OPENAI_API_KEY`, `OPENAI_MODEL(S)`, `OPENAI_BASE_URL` | Optional OpenAI models. |
| `XAI_API_KEY` (or `GROK_API_KEY`), `XAI_MODEL(S)`, `XAI_BASE_URL` | Optional Grok models. |
| `LLM_BASE_URL`, `LLM_MODEL`, `LLM_API_KEY` | Optional OpenAI-compatible endpoint. |
| `OLLAMA_BASE_URL`, `OLLAMA_MODEL` | Optional local model. |
| `GEMINI_TTS_MODEL`, `GEMINI_TTS_VOICE`, `GEMINI_TTS_RPM`, `TTS_PROVIDER` | Natural voice. Free tier allows 3 voice requests a minute and a small daily amount; set `GEMINI_TTS_RPM` to your plan's limit. `TTS_PROVIDER=off` disables it. |
| `PORT`, `MAX_BODY_BYTES` | Local server settings. |

---

## 5. Core algorithms

### Computed lessons
1. **Route** (`director.mjs`): regex routes map the typed topic to an algorithm and read the student's input (`[5, 1, 4]`, `1-2, 2-3 from 1`, `push 3, pop`, `fib(5)`).
2. **Execute** (`tracers.mjs`): the real algorithm runs and records every step as `{op, fact, phase, state}`. `state` is a full snapshot, so any step can be drawn on its own (seeking, replays, inserted scenes).
3. **Direct** (`director.mjs`): steps are grouped into scenes by `phase` (for example a tree's left subtree, a sort's pass, a DFS dive). Templates add an intro, a common misconception, a checkpoint (answer computed from the trace, wrong options are the misconception's answer), a remedial scene, and a recap.
4. **Validate** (`lessonSchema.mjs`): every action must point at a real step, element and edge.
5. **Play** (`computed.js`): each beat draws its recorded state, aims the pointer at the elements it talks about, and speaks the line.

### Interrupt the professor
The server re-runs the algorithm (the client's trace is never trusted), asks the model for 1 to 3 scenes in the lesson format, validates them (real steps, real targets, no numbers outside the trace), retries once with the errors, and otherwise falls back to replaying the real steps around that point.

### AI tutor speed path
- The explanation streams from Gemini; text appears in about 2 seconds.
- The board shows the key points as they arrive, with the pointer.
- Lecture part 1 is requested as soon as its first paragraphs exist; parts 2 and 3 when the answer is complete. Up to 3 are generated in parallel and play in order.
- Lecture code uses low thinking (content already exists in the explanation).
- A model that is busy or has not started within 15 to 25 seconds hands over to the next.
- Repeated questions come from the in-memory cache.
- Measured locally: first lecture line in about 11 seconds (was about 123 seconds). Netlify now runs the same code, so it has streaming and the early start too (not yet measured on the live site).

### Natural voice
A scene's lines are sent in one TTS request with paragraph breaks. The server finds silent gaps in the audio and snaps each expected line boundary (from text length) to the nearest pause, so each line plays with its frame. Requests are paced to the plan's per-minute limit and retried after rate-limit errors.

---

## 6. PDF tutor

**Frontend (`app.js`, `handlePdfFile`):**
1. The student attaches a PDF (text PDFs only, up to 40 MB). pdf.js reads it **in the browser**; the file itself is never uploaded.
2. Text is extracted page by page. If there is no text (a scanned image PDF), it stops and says so.
3. Pages are grouped into sections of about 800 words (`chunkPages`).
4. A whole-document summary is requested first from `/api/explain`, using even samples from the start, middle and end of the document, capped at 18,000 characters (`docSummarySource`).
5. Each section is queued as a lecture part (`kind: 'doc'`) and drawn in order.

**Backend:** `/api/code-lesson` with `pdf: true` adds DOCUMENT MODE instructions: explain every idea in the section, one beat per idea, up to 24 beats, without summarizing other parts.

**Scanned PDFs:** when a PDF has no text layer, `readScannedPages` in `app.js` draws each page (up to 30) to a JPEG in the browser and sends it to `POST /api/ocr`, which transcribes it with Gemini (Flash-Lite first, busy models hand over), then the normal flow continues. Tested: a page read word for word in about 1.7 s. Off in Instant mode.

**Limits today:** the uploaded document itself is not stored (refreshing loses it, though finished lectures are saved), only section text is sent to the AI, scanned PDFs are read up to 30 pages.

---

## 7. Data, progress, streaks and notifications

### How data is stored today
There is **no database and no accounts**. Everything personal is kept in the student's browser (`localStorage`), and the server is stateless apart from short-lived in-memory caches.

| Key | Contents |
|---|---|
| `nl.progress` | One record per algorithm: `{done, right, at, ms, runs, input, target}` (see below). |
| `nl.notes.<algorithm>`, `nl.notes.tutor` | The student's own notes from the Notes tab. |
| `nl.name` | Name used in greetings and the avatar. |
| `nl.theme` | `light` or `dark`. |
| `nl.model` | Chosen AI model. |
| `nl.voiceChoice`, `nl.voiceStyle` | Chosen voice and speaking style. |
| `nl.verify` | Fact check on (`1`) or off (`0`). |
| `nl.instant` | Instant mode (no AI calls). |
| `nl.days` | Days with a finished lesson (local dates), for the streak. |
| `nl.runs` | The run log: one entry per finished lesson (newest 1000). |
| `nl.guest` | Chose to continue without an account. |
| `nl.auth` | Supabase session (only when signed in). |
| `nl.tour.<page>` | That page's guided tour has been seen or skipped (`nl.tourDone` is the older Home flag). |

Consequence: progress does not follow the student to another device or browser, and clearing site data erases it.

### Progress and completed lessons (built)
- When a lesson starts: `input`, `target`, `at` are saved.
- When it finishes (`computed:finish`): `done: true`, `right` (true if every checkpoint was answered right, and stays true once earned), `at` (time), `ms` (total time spent, accumulated), `runs` (number of completions).
- Status shown on cards: **Completed** (`done` and `right`), **Checkpoint missed** (`done` but not `right`), **In progress** (started, not finished), **Not started**.
- Used by: Home stat tiles, "Continue" / "Up next" card, Recommended next (next lessons not mastered, prerequisites first), Library cards and module counts, Progress page (per-module bars, recent lessons).

### Progress page (built)
`renderProgress` in `shell.js`, numbers from `public/app/progress-stats.js` (pure functions, tested in `tests/progress.test.mjs`):
- **Run log** `nl.runs`: one entry per finished lesson `{id, at, algo, ms, checks, correct, input}` (newest 1000), synced to `lesson_runs` (`supabase/003_lesson_runs.sql`) by id, so runs from every device merge. Without that table the log still works in the browser.
- **Six tiles:** lessons completed (and in progress), mastered, time spent, current streak (with a "finish a lesson today" nudge), longest streak, checkpoint accuracy.
- **Activity calendar:** 17 weeks, Monday first, darker = more lessons, hover for the day's lessons and time. **This week:** a bar per day, compared with last week.
- **Needs review:** finished lessons whose checkpoint was missed, with Retry. **By module:** mastered and finished bars, plus a chip per lesson that opens it. **Recent activity:** each run with its result, time and input.
- **Export CSV** (every run) and **Reset progress** (confirmation dialog; clears progress, streak and run log from the browser and, when signed in, the account; notes and saved lectures stay).
- Empty state for new students; works signed in or as a guest; phone, dark mode and keyboard tested.

### Learning streaks (built)
- **What it counts:** consecutive calendar days on which the student finished at least one lesson.
- **How:** collect the dates of all completed lessons; count back day by day from today (or from yesterday if nothing was finished today, so the streak isn't lost before the day ends).
- **Where it shows:** the flame tile on Home and on the Progress page.
- **Purpose:** a daily habit nudge.
- **Limits:** uses the browser's date in UTC; no streak freezes; per browser only.

### Notifications (built, in memory)
The bell shows events from the current visit only:
- a lesson finished, and whether the checkpoint was right;
- the fact check flagged claims in an answer;
- a model was busy and another one answered;
- the model or voice changed, or the natural voice fell back to the device voice;
- Verified mode was turned on or off.

They are not saved, and nothing is sent while the app is closed.

### Accounts and cloud sync (built, needs a Supabase project to switch on)
**Stack:** Supabase (Postgres + Auth), called straight from the browser with `@supabase/supabase-js@2.45.4` (loaded from jsDelivr only when accounts are set up). No server-side secret is involved: the project URL and the **publishable** (anon) key are public by design, and row level security makes every table return and accept only the signed-in student's rows. The `service_role` key is never used.

**Switching it on:**
1. Create a Supabase project. In the SQL editor, run `supabase/schema.sql` (tables + row level security).
2. Supabase → Authentication → URL Configuration: Site URL `https://storied-churros-164bf2.netlify.app/app/`; add redirect URLs for that and for `http://127.0.0.1:4173/app/`.
3. Set `SUPABASE_URL` and `SUPABASE_ANON_KEY` (the **publishable** key, `sb_publishable_…`; the legacy anon JWT also works) in Netlify (and `.env` locally), then redeploy. `GET /api/config` then returns them; without them it returns `{accounts: null}` and the app stays browser-only, exactly as before.

**Data model (`supabase/schema.sql`):**

| Table | Columns | Mirrors in the browser |
|---|---|---|
| `profiles` | `id` (= auth user), `name`, `timezone`, `updated_at` | `nl.name` |
| `topic_progress` | `user_id`, `algorithm`, `done`, `right`, `runs`, `ms`, `input`, `target`, `at`; key (`user_id`, `algorithm`) | `nl.progress` |
| `notes` | `user_id`, `key` (`tutor` or an algorithm), `text` | `nl.notes.<key>` |
| `streak_days` | `user_id`, `day` (the student's local date) | `nl.days` |
| `notifications` | `id`, `user_id`, `kind`, `text`, `created_at`, `read_at` | the bell (last 20) |
| `lesson_runs` | `id` (made in the browser), `user_id`, `algorithm`, `finished_at`, `ms`, `checkpoints`, `correct`, `input` | `nl.runs` |
| `saved_lectures` | `id`, `user_id`, `title`, `kind` (chat or doc), `explanation`, `parts` (jsonb: title, kind, text, html, model, pages), `part_count`, `model`, `created_at` | none (fetched when My Library opens) |

**How it works (`public/app/account.js`):**
- localStorage stays the working copy, so pages read instantly; every change is also saved in the background (`pushProgress`, `pushNote`, `pushDay`, `pushNotification`, `pushName`). A failed save is repaired by the next sync.
- On sign-in, `pull()` merges the account with the browser: a lesson finished on either side stays finished, counts take the larger value, saved notes win, streak days are combined. So progress made as a guest is kept when the student signs up.
- Sign-out clears the personal keys from the browser (shared computers).
- Screens: `#/login` (sign in, create account, forgot password, set a new password from the email link, or continue as a guest: `nl.guest`). With accounts on, a signed-out student who hasn't chosen guest mode is sent there first; after signing in they land on Home, where the Home tour plays on the first visit. The profile menu shows the account and Sign out.
- Streak days now use the student's own timezone (they used UTC before).
**Saved lectures (`public/app/saved.js`, table `saved_lectures` from `supabase/002_saved_lectures.sql`):** when every part of an AI tutor or PDF lecture has been drawn, the lecture (question, written answer, and each part's lesson HTML, narration text and model) is saved to the signed-in student's account. My Library shows them under "Saved lectures" with Play (replays instantly from the saved HTML, no AI calls; `window.playSavedLecture` in `app.js`) and Delete. The list query leaves out the heavy `parts` column; a lecture is fetched whole when played. Limit about 6 MB per lecture. Guests are told once that signing in keeps lectures. They are stored as the lessons themselves.

**Downloads (`public/app/download.js`):** the player's ⬇ Download menu (any lecture on the board, signed in or not) and the Download button on saved cards. *Lecture file (.html)*: one self-contained file with every part's lesson HTML (JSON block, `<` escaped), the pointer kit and a small player (subtitles, browser voice, part navigation, the written answer); it plays offline. *Video*: `getDisplayMedia` tab capture of this tab, cropped to the board with Region Capture where supported, recorded with `MediaRecorder` as MP4 (Chrome/Edge) or WebM while the lecture replays from the start; it stops when the lecture ends (`lecture:ended` event) or when sharing stops. The natural voice is recorded when the student ticks "Share tab audio"; the device voice is not captured by browsers.
- Not built yet: usage_events (per-user token limits), saving PDFs, email reminders ("your streak ends tonight"), Google sign-in.

## 8. Token counter and timing (built)

**What the student sees:** under each AI tutor answer, one line such as "9,475 tokens · 2,540 in · 4,631 out · 2,304 thinking · first text 4.6 s · 39.5 s total". Hovering it shows how many model calls the message took and the model time added up. Under the chat, a running total for the browser tab: "This session: … tokens · N answers · … of model time".

**How it works:**
- Server (`lib/models.mjs`): every request has a usage record in its AsyncLocalStorage store. Each model call adds its counts with `noteUsage`: Gemini `usageMetadata` (prompt, candidates, thoughts; in a stream the last chunk's running totals), OpenAI and Grok `usage` (reasoning tokens counted as thinking), Ollama `prompt_eval_count` and `eval_count`.
- JSON answers carry `x-usage: {"calls","in","out","think","ms"}` (`send()` in `server.mjs`). The streamed explanation puts `usage` in its final `{done}` line.
- Browser: `models.js` reads `x-usage` from every API answer and `app.js` reads the stream's last line; both fire a `usage` event. `usage.js` adds the events up under the message that started them (`Usage.begin` when a question is sent; the answer, each lecture part and the fact check all count), and into a total kept in `sessionStorage`.
- "First text" is measured in the browser, from sending the question to the first streamed words. "Total" is from sending to the last request that reported.
- Not counted yet: the natural voice (TTS) and computed-lesson AI narration outside a chat message (those go into the session total only).
- Later: save each record in `usage_events` for per-user limits and cost reports.

---

## 9. Managing the library

- The curriculum lives in `lib/catalog.mjs`: `MODULES` (teaching order) and `TOPICS` (description, level, time and space complexity, prerequisites, input format, examples).
- **To add an algorithm:**
  1. Write a tracer in `lib/tracers.mjs` and register it in `ALGORITHMS`.
  2. Add teaching templates and scene titles in `lib/director.mjs`, and a route regex.
  3. Add an entry to `TOPICS` and the module in `lib/catalog.mjs`.
  4. If it needs a new kind of picture, add a view in `public/app/computed.js` (returning the points the pointer should visit), and target/edge rules in `lib/lessonSchema.mjs`.
  5. Add its Python and line mapping in `public/app/codesamples.js`.
  6. Add tests in `tests/computed.test.mjs`; a catalog test checks every example builds a clean lesson.

---

## 10. Guardrails against hallucination

**Built:**
1. **Computed frames.** The AI never draws computed lessons; every frame is a recorded state.
2. **Schema validation.** AI-chosen scenes may only point at real steps, existing elements and real edges.
3. **Number guard.** Reworded narration is rejected if it mentions any number not in the line it replaces.
4. **Server-side recompute.** Interrupts re-run the algorithm on the server; the browser's copy is never trusted.
5. **Retry, then fallback.** Invalid AI answers are retried once with the errors, then replaced by a replay of the real steps.
6. **Checkpoint answers from the trace,** never from the model.
7. **Fact check for the AI tutor (Verified mode):**
   - Rules without AI: arithmetic in equations, time complexities of well-known algorithms, numbers in lecture lines that the explanation never mentions.
   - Independent reviewer: lists checkable claims and works them out; every claim must be quoted from the answer, or it is dropped.
   - Second opinion: a claim stays "Wrong" only if a second separate check agrees; otherwise it shows as "Check this". A rule result beats an AI opinion.
   - Flagged sentences are highlighted, corrections are shown, and lecture subtitles that repeat a flagged claim show the correction.
8. **Lecture prompt rules.** Lectures for chat answers must narrate the explanation's own sentences without adding facts.
9. **Sandboxing.** Generated lectures run in a sandboxed iframe with no access to the app.

10. **Different reviewer model.** The browser sends the model that wrote the answer (`writer`); `reviewerFor` in `lib/models.mjs` picks another provider first, then another model, and the result says which model reviewed it.
11. **Wrong lines are held back.** In a lecture, a line that repeats a claim marked wrong is replaced by "Correction: …" in the voice and subtitles (`lectureLine` in `app.js`); "check this" lines are kept and marked.
12. **PDF lectures stay with the document.** Lecture lines of a PDF section are checked against that section: new numbers, or fewer than 30% of the line's content words found in the section, mark the line "check this".
13. **Known facts.** `lib/facts.mjs` holds rule checks with no model call (stack LIFO, queue FIFO, O(1) stack and queue operations, array access, hash tables, BST inorder order, heap peek, binary search needs sorted data, merge sort space and stability, BFS queue and DFS stack, Dijkstra and negative weights, naive Fibonacci, TCP three-way handshake, UDP reliability, Ohm's law, photosynthesis). Each entry says what it is about, what contradicts it, what makes it fine, and the correction. Add facts there, with a test.

---

14. **Where each fact came from.** In Verified mode the AI tutor answers *from sources it looked up first*, so every cited sentence traces to a real page:
    - `lib/retrieve.mjs` searches Wikipedia's free API (no key, no quota) for the question, takes the passages most relevant to it from the top 3 articles (opening paragraph plus the best-matching paragraphs, skipping See also / References), and gives them to the model as numbered SOURCES with rules: put [n] after each sentence that uses a source, cite only what the passage states, leave own explanations unnumbered. Works with any model, Gemini or OpenAI.
    - The stream starts with `{looked: [titles]}` ("Read 3 Wikipedia articles first: …"); the final line carries `sources` (`mode: 'retrieved'`): each article with its link and the exact passage given to the model, which articles the answer actually used, and which sentences cite which source.
    - `public/app/sources.js` turns the [n] markers into clickable numbers, lists the used articles (Trusted badge, "The passage the tutor read") and the read-but-unused ones apart, and says how many sentences have a source. Sentences without a number are the tutor's own explanation. The lecture, voice, fact check and chat history get the text without markers (`Sources.strip`).
    - Optional: `GEMINI_SEARCH_GROUNDING=true` makes Gemini search Google itself instead (`lib/sources.mjs` rates any site as trusted / reputable / not on the list). That needs Google Search quota (billing on the Google project); if refused (429) the answer is written without it and the box says so.

---

## 11. Known issues and next steps

1. **Netlify has one model:** set `GEMINI_MODELS=gemini-3.5-flash,gemini-3.8-flash,gemini-flash-lite-latest` in Netlify's environment variables and redeploy. Right now AI answers fail whenever `gemini-flash-latest` is busy.
2. ~~Netlify lacks the speed path~~ **Fixed:** Netlify runs `server.mjs` through `lib/netlify.mjs`, with streaming and model hand-over. Needs a redeploy to go live.
3. **Netlify time limit (60 s, checked in Netlify's docs):** requests stop at 55 s with a clear error. Lecture parts are short, so they normally finish well inside it; a long PDF section on a slow model could still hit it. If that happens in practice, move `/api/code-lesson` to a Background Function (15 min) that saves the result to Netlify Blobs while the browser checks back.
4. ~~One failing test~~ **Fixed.** All 32 tests pass (`node --test`).
5. **Rotate the Gemini key** (it was shared in a chat).
6. **Natural voice quota:** the free tier is about one lesson's worth a day. Each scene of natural voice is now saved in the browser (IndexedDB `nl-voice`, the newest 80 scenes, `voice.js`) and the server keeps the last 40 in memory, so replays and saved lectures don't use the quota again. A paid key, or Edge's free "Natural" voices, still helps for new lectures.
7. **Accounts are on** (Supabase, section 7). Phases 0 to 5 of the plan are done.
8. ~~Landing page~~ **Done:** redesigned to match the app (light and dark, live inorder board with the pointer, current features, 14 algorithms).
9. ~~Put the project in git~~ **Done** (local repository, branch `main`, `.env` ignored). Not pushed anywhere yet.
